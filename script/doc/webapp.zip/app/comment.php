<!-- start -->
<?php
require_once "config.php";
require_once 'protect.php';
$name = $_POST['name'];
$comment = $_POST['comment'];
$strname = str_ireplace( 'alert', '', $_POST['name'] ); 
$strcomment = str_ireplace( 'alert', '', $_POST['comment'] );
$con = mysqli_connect("db", "php_docker", "password", "php_docker");
$query = "INSERT INTO commentsNew (name, comment) VALUES ('$strname', '$strcomment')";
$result = mysqli_query($con, $query);
header("Location:feedback.html");
?>
<!-- end -->
<html>
   <title>StoryBoard</title>
   <head>
      <title>Types Page</title>
	      <!-- CSSstart -->
	  	  <link rel="stylesheet" href="styles1.css">
		  <!-- CSSend -->   </head>
   <body>
   </body>
</html>