<!-- start -->
<?php
require_once "config.php";
require_once 'protect.php';
require_once 'auth_check.php';
$con = mysqli_connect("db", "php_docker", "password", "php_docker");
$sql = "SELECT * FROM commentsNew";
$result = mysqli_query($con, $sql);
while ($row = $result->fetch_assoc()) {
	$row['name'] = htmlspecialchars($row['name'],ENT_QUOTES,'UTF-8');
	$row['comment'] = htmlspecialchars($row['comment'],ENT_QUOTES,'UTF-8');
	echo "name:"; echo $row['name']."<br>";
    echo "comment:"; echo $row['comment']."<br><br>";
}
?>
<!-- end -->
<html>
   <title>StoryBoard</title>
   <head>
      <title>Types Page</title>
	      <!-- CSSstart -->
	  	  <link rel="stylesheet" href="styles1.css">
		  <!-- CSSend -->   </head>
   <body>
   </body>
</html>