<!-- start -->
<?php
        require_once "config.php";
        require_once 'protect.php';
        require_once 'auth_check.php';
		if(isset($_GET["id"]))
		{    
        $id=$_GET['id'];
        $con = mysqli_connect("db", "php_docker", "password", "php_docker");
        $query="SELECT * FROM products WHERE id= $id";
        $result = mysqli_query($con, $query);
		    echo "<table border='1' align='center'>
<H2 align='center'> Products Table </h2>
<tr>
<th>Product Type</th>
<th>Product Name</th>
<th>Product Price</th>
</tr>";
while ($fetch = mysqli_fetch_array($result))
    {
        echo "<tr>";
        echo "<td>" . $fetch['type'] . "</td>";
        echo "<td>" . $fetch['name'] . "</td>";
        echo "<td>" . $fetch['price'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}
		
 ?>
 <!-- end -->
 <html>
   <title>StoryBoard</title>
   <head>
      <title>Types Page</title>
	      <!-- CSSstart -->
	  	  <link rel="stylesheet" href="styles1.css">
		  <!-- CSSend -->   </head>
   <body>
   </body>
</html>