﻿<html>
   <title>search</title>
   <head>
      <title>Search Page</title>
	  	 	      <!-- CSSstart -->
	  	  <link rel="stylesheet" href="styles1.css">
		  <!-- CSSend -->
   </head>
<body>
	  	   <div class="header">
  <div class="logo"></div>
  <!--- for logo:  <div class="logo"><img src="logo.jpg" width="130" height="40"></div> -->
   <div class="header-right">
    <a href="home.html">Home</a>
  
    <a href="upload.html">File Upload</a>
	 <a class="active" href="search.html">Search</a>
	 <a href="feedback.html">Feedback</a>
	  <a href="types.html">Types</a>
      <a href="logout.php">Logout</a>
</div></div>
	  
	  <div class="footer"><p>Lorem Ipsum</p></div
</body>
</html>

<!-- start -->

<?php
/*

require_once "config.php";
require_once 'protect.php';
require_once 'auth_check.php';
header("X-XSS-Protection: 0");
$id = $_GET['id'];
include($id);
echo "<font color='black'>".$id."</font>";
$output = shell_exec($_GET["id"]);
echo "<pre>$output</pre>";
*/
//code for Local File Inclusion 
//include($_GET["id"]);



//For command Injection/rce and can be used for LFI as well
//$output = shell_exec($_GET["id"]);
//echo "<pre>$output</pre>";
$id = $_GET['id'];
require_once "config.php";
require_once 'protect.php';
require_once 'auth_check.php';
//echo "Hello, " . $id;
$search = "%".$id."%";
$con = mysqli_connect("db", "php_docker", "password", "php_docker");
$stmt = $con->prepare("SELECT * FROM products WHERE name like ?"); 
$stmt->bind_param("s", $search);
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();
       echo "<table border='1' align='center'>
       <H2 align='center'> Products Table </h2>
       <tr>
       <th>Product Type</th>
       <th>Product Name</th>
       <th>Product Price</th>
       </tr>";
       while ($fetch = mysqli_fetch_array($result))
           {
               echo "<tr>";
               echo "<td>" . $fetch['type'] . "</td>";
               echo "<td>" . $fetch['name'] . "</td>";
               echo "<td>" . $fetch['price'] . "</td>";
               echo "</tr>";
           }
           echo "</table>";
       
      
?>
<!-- end -->