<?php
if(!isset($SESSION['username'])){
  header("Location: index.php");
}
?>