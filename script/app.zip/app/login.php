




       <?php
              require_once "config.php";
       if(isset($_GET["id_submit"]))
       {    
           $username=$_GET['username'];  
           $password=$_GET['password'];  
           $query=mysqli_query($db,"SELECT * FROM users WHERE username='$username' AND password='$password'");
           if(mysqli_num_rows($query) > 0){
               while($data = mysqli_fetch_assoc($query)){
                   header("Location: home.php");}  
           }else{
                echo '<span style="color:white;text-align:center;">Invalid username and password</span>';
           } 	
       }	
       ?>
       <!-- end -->
<!DOCTYPE HTML> 
<!-- Website template by freewebsitetemplates.com --> 
<html> 
    <head> 
        <meta charset="UTF-8"> 
        <title>Login - StoryBoard</title>         
        <link rel="stylesheet" href="css/style.css" type="text/css"> 
    </head>     
    <body> 
        <div id="header"> 
            <div> 
                <div class="logo"> <a href="home.php">StoryBoard</a> 
                </div>                 
                <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous">
		</script>                          
        </div>         
    </div>     
    <div id="contents"> 
        <div id="about"> 
            <h3>Login</h3> 
            <form action="" method="GET"> 
                <label>UserName : </label>
                <input type="text" name="username" required class="box"/>
                <br/>
                <br/> 
                <label>Password : </label>
                <input type="password" name="password" class="box"/>
                <br/>
                <br/> 
                <input type="submit" value="Submit " name="id_submit" required/>
                <br/></br> <a href="signup.php">Create an account</a> 
            </form>             
        </div>         
    </div>     
    <div id="footer"> 
        <div class="clearfix"> 
            <div id="connect"> <a href="http://freewebsitetemplates.com/go/facebook/" target="_blank" class="facebook"></a>
                <a href="http://freewebsitetemplates.com/go/googleplus/" target="_blank" class="googleplus"></a>
                <a href="http://freewebsitetemplates.com/go/twitter/" target="_blank" class="twitter"></a>
                <a href="http://www.freewebsitetemplates.com/misc/contact/" target="_blank" class="tumbler"></a> 
            </div>             
            <p> 
				© 2023 Love.
 </p> 
            <p> Designed by freewebsitetemplates.com</p> 
        </div>         
    </div>     
</body> 
